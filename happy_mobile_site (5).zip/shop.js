let cart = [];

function addToCart(name, price) {
  cart.push({ name, price });
  alert(name + " добавлен в корзину!");
  localStorage.setItem("cart", JSON.stringify(cart));
}

document.addEventListener("DOMContentLoaded", () => {
  const cartItems = document.getElementById("cart-items");
  const totalEl = document.getElementById("total");
  const form = document.getElementById("order-form");

  if (cartItems && totalEl) {
    const savedCart = JSON.parse(localStorage.getItem("cart")) || [];
    let total = 0;
    savedCart.forEach(item => {
      const li = document.createElement("li");
      li.textContent = `${item.name} - ${item.price} ₸`;
      cartItems.appendChild(li);
      total += item.price;
    });
    totalEl.textContent = total + " ₸";
  }

  if (form) {
    form.addEventListener("submit", e => {
      e.preventDefault();
      alert("Заказ оформлен! С вами свяжется менеджер.");
      localStorage.removeItem("cart");
      form.reset();
    });
  }
});
